OWi Cockpit – Pressepaket
=========================

Datenstand der App: Tatbestandskatalog Stand 08.10.2026.
Kontakt: owi-cockpit@thomasnagel.org

Kurzbeschreibung
----------------
OWi Cockpit ist eine iPhone-App für Bußgeldsachen im Straßenverkehr: Tatbestandsnummer, Regelgeldbuße, Punkte, Fahrverbot und Verjährung auf einen Blick, bedient mit Rädern, Schiebern und Schaltern statt Tastatur. Keine Konten, keine Werbung, kein Tracking.

Langbeschreibung
----------------
OWi Cockpit ist für alle gemacht, die einen Bußgeldbescheid oder eine OWi-Akte vor sich haben: Gerichte, Anwaltschaft, Bußgeldstellen und Betroffene. Oben steht das Ergebnis in einer eingelassenen Anzeige, darunter ersetzen Räder, Schieber und Schalter die Tastatur, und nichts auf dem Bildschirm springt. Die App ist aus über zehn Jahren täglicher Arbeit mit Bußgeldsachen entstanden und von einer Person gestaltet und gebaut. Keine Konten, keine Werbung, kein Tracking.

Inhalt
------
bildschirmfotos/   Bildschirmfotos in voller Auflösung, ohne Gerätegehäuse
  1-tempo  Tempo: Tatbestandsnummer, Regelgeldbuße, Punkte und Fahrverbot, kostenlos
  2-verjaehrung  Verjährung als Zeitstrahl, mit altem Recht für Taten bis 30.06.2026
  3-rechner  Rechner für Vorsatz, Voreintragungen im FAER und Absehen vom Fahrverbot gegen Erhöhung
  4-sonstige  Fast 300 weitere Tatbestände von Handy bis Parken
  5-ptb  Messgeräte mit den Stellungnahmen der PTB
icon/              App-Icon 1024 x 1024 px, hell und dunkel

Hinweise
--------
Alle Bildschirmfotos zeigen neutrale, erfundene Beispielfälle. OWi Cockpit ist ein Arbeitshilfsmittel; die Angaben sind
nicht amtlich und ersetzen weder die Prüfung im Einzelfall noch eine Rechtsberatung.
Die Bilder dürfen für Berichte über OWi Cockpit verwendet werden. Gerätegehäuse sind nicht enthalten.
