noka press kit

noka - private shopping lists for iPhone. Never Out of Kiwis Again.
No tracking, no ads, no account.

app-icon/             App icon, 1024 x 1024 px (light and dark)
wordmark/             Wordmark as SVG (outlined, no font needed) and PNG, light and dark, with and without tagline
photos-iphone-duo/    iPhone Duo: open landscape, half-folded landscape, folded landscape, folded portrait, open portrait
photos-iphone-17/     iPhone 17: home, store list, setup, support
                      Each photo exists in light and dark; the subfolder screenshots/ holds the plain
                      full-resolution screenshots without a device frame.

Contact: noka@thomasnagel.org - https://thomasnagel.org/noka/press/
