noka press kit

noka - private shopping lists for iPhone. Never Out of Kiwis Again.
No tracking, no ads, no account.

app-icon/             App icon, 1024 x 1024 px (light and dark)
wordmark/             Wordmark as SVG (outlined, no font needed) and PNG, light and dark, with and without tagline
photos-iphone-duo/    iPhone Duo screenshots: open landscape, folded landscape (camera left and right), folded portrait,
                      open portrait, in light and dark; folded layouts also with the largest text size
photos-iphone-17/     iPhone 17 screenshots: home, store list, setup, support, in light and dark

All photos are full-resolution simulator screenshots without a device frame.

Contact: noka@thomasnagel.org - https://thomasnagel.org/noka/press/
